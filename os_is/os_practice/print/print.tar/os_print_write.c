#include<stdio.h>

void main(){

	printf("123\n");
	write(1,"45",2);
	printf("a");
	printf("b");
	write(1,"78",1);
	printf("\n");
	write(1,"91",1);
	printf("\n");
}
