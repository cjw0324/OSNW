#include<stdio.h>

extern void sum10();

void id(){
	printf("32184682 최재우\t");
	sum10();
}
