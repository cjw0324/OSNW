#include <stdio.h>

int main(int argc, char **argv)
{
	getc(stdin);
	return 0;
}       
